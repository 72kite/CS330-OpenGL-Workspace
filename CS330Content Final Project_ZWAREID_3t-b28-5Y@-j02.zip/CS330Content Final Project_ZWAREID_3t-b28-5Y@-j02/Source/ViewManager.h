///////////////////////////////////////////////////////////////////////////////
// ViewManager.h
// ============
// Manage the viewing of 3D scenes - camera and projection
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Modified by: [Your Name]
// Created for CS-330-Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////
#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include "GLFW/glfw3.h"

class ViewManager
{
public:
	// Constructor and Destructor
	ViewManager(ShaderManager* pShaderManager);
	~ViewManager();

	// Creates the GLFW display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);

	// Prepares the view matrix and projection matrix for rendering
	void PrepareSceneView();

	// Mouse callback functions (must be static for GLFW)
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset);

private:
	// Private member variables
	ShaderManager* m_pShaderManager;
	GLFWwindow* m_pWindow;

	// Variable to track projection mode (false = Perspective, true = Orthographic)
	bool bOrthographicProjection;

	// Private methods
	void ProcessKeyboardEvents();
};