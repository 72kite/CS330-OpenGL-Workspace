///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// Manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Modified by: [Your Name]
// Created for CS-330-Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <string>
#include <vector>

class SceneManager
{
public:
	// Constructor and Destructor
	SceneManager(ShaderManager* pShaderManager);
	~SceneManager();

	// Texture information structure
	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	// Material properties structure
	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

	// Public methods
	void PrepareScene();
	void RenderScene();

private:
	// Member variables
	ShaderManager* m_pShaderManager;
	ShapeMeshes* m_basicMeshes;
	int m_loadedTextures;
	TEXTURE_INFO m_textureIDs[16];
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// Helper methods for rendering complex objects
	void RenderMonitor();
	void RenderCoffeeMug();
	void RenderNotebooks();
	void RenderPencilCup();

	// Transformation and color methods
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// --- TEXTURE METHODS (Milestone 4) ---
	bool CreateGLTexture(const char* filename, std::string tag);
	void BindGLTextures();
	void DestroyGLTextures();
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	void SetShaderTexture(std::string textureTag);
	void SetTextureUVScale(float u, float v);
	void LoadSceneTextures();

	// --- LIGHTING & MATERIAL METHODS (Final) ---
	void SetupSceneLights();
	void DefineObjectMaterials();
	void SetShaderMaterial(std::string materialTag);
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
};