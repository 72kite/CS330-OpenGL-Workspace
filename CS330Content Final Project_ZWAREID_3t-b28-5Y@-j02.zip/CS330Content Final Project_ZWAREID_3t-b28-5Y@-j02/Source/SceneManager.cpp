///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// Manages the loading and rendering of the 3D desktop workspace scene
// Milestone Four & Final: Advanced Texturing and Lighting Implementation
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Modified by: [Your Name]
// Created for CS-330-Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// ============================================================================
// NAMESPACE - Shader Uniform Names
// ============================================================================
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

// ============================================================================
// CONSTRUCTOR & DESTRUCTOR
// ============================================================================

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	DestroyGLTextures();
}

// ============================================================================
// TEXTURE MANAGEMENT METHODS
// ============================================================================

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

	if (image)
	{
		std::cout << "[SUCCESS] Loaded texture: " << filename
			<< " (" << width << "x" << height << ", "
			<< colorChannels << " channels)" << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "[ERROR] Unsupported format: " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "[ERROR] Failed to load texture: " << filename << std::endl;
	return false;
}

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}
	return textureID;
}

int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}
	return textureSlot;
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);
		int textureSlot = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
	}
}

void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

void SceneManager::LoadSceneTextures()
{
	std::cout << "\n=== Loading Scene Textures ===" << std::endl;
	CreateGLTexture("desk.jpg", "desk");
	CreateGLTexture("screen.jpg", "screen");
	CreateGLTexture("bezel.jpg", "bezel");
	CreateGLTexture("ceramic.jpg", "ceramic");
	CreateGLTexture("paper.jpg", "paper");
	CreateGLTexture("metal.jpg", "metal");
	std::cout << "=== Total Textures Loaded: " << m_loadedTextures << " ===" << std::endl << std::endl;
	BindGLTextures();
}

// ============================================================================
// TRANSFORMATION & COLOR METHODS
// ============================================================================

void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 scale = glm::scale(scaleXYZ);
	glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 translation = glm::translate(positionXYZ);

	glm::mat4 modelMatrix = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelMatrix);
	}
}

void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);

	if (NULL != m_pShaderManager)
	{
		// Disable texture, but KEEP LIGHTING ENABLED
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setIntValue(g_UseLightingName, true);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

// ============================================================================
// LIGHTING AND MATERIAL METHODS (Final Project Updates)
// ============================================================================

void SceneManager::SetupSceneLights()
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseLightingName, true);

		// ====================================================================
		// PRIMARY LIGHT - Moved over the monitor (Z = 1.0f) and slightly brighter
		// ====================================================================
		m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(0.0f, 0.75f, 1.0f));
		m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.1f, 0.1f, 0.1f));
		m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.8f, 0.6f, 0.4f));
		m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.4f, 0.4f, 0.4f)); // Bumped for defined highlight
		m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 1.0f);
		m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.4f);

		// SECONDARY LIGHT (Fill Light)
		m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-8.0f, 3.0f, -8.0f));
		m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.05f, 0.05f, 0.08f));
		m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.15f, 0.15f, 0.2f));
		m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.1f, 0.1f, 0.1f));
		m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
		m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.1f);
	}
}

void SceneManager::DefineObjectMaterials()
{
	// Material for plane - Adjusted to prevent texture blowout
	OBJECT_MATERIAL planeMaterial;
	planeMaterial.ambientStrength = 0.3f;
	planeMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	planeMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f); // Lowered from 0.8
	planeMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); // Lowered from 0.8
	planeMaterial.shininess = 16.0f; // Lowered to spread the highlight out
	planeMaterial.tag = "plane";
	m_objectMaterials.push_back(planeMaterial);

	// Material for complex objects
	OBJECT_MATERIAL complexMaterial;
	complexMaterial.ambientStrength = 0.4f;
	complexMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	complexMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	complexMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	complexMaterial.shininess = 2.0f;
	complexMaterial.tag = "complex";
	m_objectMaterials.push_back(complexMaterial);
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	for (size_t i = 0; i < m_objectMaterials.size(); i++)
	{
		if (m_objectMaterials[i].tag == tag)
		{
			material = m_objectMaterials[i];
			return true;
		}
	}
	return false;
}

void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (NULL != m_pShaderManager)
	{
		OBJECT_MATERIAL material;
		if (FindMaterial(materialTag, material))
		{
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadPrismMesh();
}

// ============================================================================
// OBJECT RENDERING METHODS
// ============================================================================

void SceneManager::RenderMonitor()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	SetShaderMaterial("complex"); // Complex object, low reflection

	scaleXYZ = glm::vec3(3.0f, 0.15f, 2.0f);
	positionXYZ = glm::vec3(0.0f, 0.075f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(0.5f, 2.0f, 0.5f);
	positionXYZ = glm::vec3(0.0f, 1.0f, -0.5f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);
	m_basicMeshes->DrawTaperedCylinderMesh();

	scaleXYZ = glm::vec3(8.0f, 4.5f, 0.3f);
	positionXYZ = glm::vec3(0.0f, 2.8f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(7.6f, 4.1f, 0.31f);
	positionXYZ = glm::vec3(0.0f, 2.8f, 0.02f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderTexture("screen");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::RenderCoffeeMug()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	SetShaderMaterial("complex");

	// --- LAYER 1: The Liquid (resting at the very bottom) ---
	scaleXYZ = glm::vec3(0.85f, 0.01f, 0.85f);
	// Half of 0.01 height = 0.005
	positionXYZ = glm::vec3(5.0f, 0.005f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.1f, 0.1f, 0.1f, 0.3f);
	m_basicMeshes->DrawCylinderMesh();

	// --- LAYER 2: Lower Mug Body ---
	scaleXYZ = glm::vec3(0.7f, 0.55f, 0.7f);
	// Half of 0.55 height = 0.275
	positionXYZ = glm::vec3(5.0f, 0.275f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.82f, 0.71f, 0.55f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// --- LAYER 3: Upper Mug Body ---
	scaleXYZ = glm::vec3(0.7f, 0.55f, 0.7f);
	// Previous height (0.55) + half of new height (0.275) = 0.825
	positionXYZ = glm::vec3(5.0f, 0.825f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// --- LAYER 4: The Rim ---
	scaleXYZ = glm::vec3(0.72f, 0.05f, 0.72f);
	// 0.55 + 0.55 + 0.025 = 1.125
	positionXYZ = glm::vec3(5.0f, 1.125f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.13f, 0.13f, 0.13f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// --- LAYER 5: The Coffee (inside) ---
	scaleXYZ = glm::vec3(0.65f, 0.03f, 0.65f);
	positionXYZ = glm::vec3(5.0f, 1.07f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.18f, 0.10f, 0.07f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// --- HANDLE: The Torus ---
	scaleXYZ = glm::vec3(0.18f, 0.3f, 0.18f);
	positionXYZ = glm::vec3(5.6f, 0.65f, 2.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 90.0f, positionXYZ);
	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
	m_basicMeshes->DrawTorusMesh();
}

void SceneManager::RenderNotebooks()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	SetShaderMaterial("complex");

	scaleXYZ = glm::vec3(3.0f, 0.2f, 4.0f);
	positionXYZ = glm::vec3(-5.0f, 0.1f, 3.0f);
	SetTransformations(scaleXYZ, 0.0f, 15.0f, 0.0f, positionXYZ);
	SetShaderColor(0.1f, 0.1f, 0.6f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(2.8f, 0.2f, 3.8f);
	positionXYZ = glm::vec3(-5.0f, 0.31f, 3.0f);
	SetTransformations(scaleXYZ, 0.0f, -5.0f, 0.0f, positionXYZ);
	SetShaderColor(0.6f, 0.1f, 0.1f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::RenderPencilCup()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	SetShaderMaterial("complex");

	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);
	positionXYZ = glm::vec3(-5.0f, 0.75f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.4f, 0.4f, 0.4f, 1.0f);
	m_basicMeshes->DrawPrismMesh();
}

// ============================================================================
// MAIN SCENE RENDERING
// ============================================================================

void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Make sure global lighting boolean is enabled for the frame
	m_pShaderManager->setIntValue(g_UseLightingName, true);

	// ============================================================
	// DESK SURFACE (Plane Mesh with TILED TEXTURE)
	// Apply "plane" material to reflect lighting actively
	// ============================================================
	SetShaderMaterial("plane");

	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderTexture("desk");
	SetTextureUVScale(6.0f, 6.0f);
	m_basicMeshes->DrawPlaneMesh();

	SetTextureUVScale(1.0f, 1.0f);

	// ============================================================
	// RENDER ALL COMPLEX SCENE OBJECTS
	// ============================================================

	RenderMonitor();
	RenderCoffeeMug();
	RenderNotebooks();
	RenderPencilCup();
}
